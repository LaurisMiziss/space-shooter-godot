extends CharacterBody3D


var speed = 5.0
var direction: float
signal shoot_laser(player_position: Vector3)


func _physics_process(delta: float) -> void:
	if Input.is_action_just_pressed("shoot"):
		shoot_laser.emit(global_position)
	
	direction = Input.get_axis("left", "right")
	velocity.x = direction * speed
	
	$craft_speederD.rotation.z = move_toward($craft_speederD.rotation.z, -direction / 3.0, delta)
	
	velocity.y = sin(Time.get_ticks_msec() / 1000.0) / 5.0 + sin(Time.get_ticks_msec() / 1200.0) / 7.0
	
	move_and_slide()
