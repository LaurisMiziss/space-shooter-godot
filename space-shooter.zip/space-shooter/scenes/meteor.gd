extends Area3D

var speed: float = 0.0
var player_position: Vector3 = Vector3.ZERO
var direction: Vector3 = Vector3.ZERO
var can_move := true


func _ready() -> void:
	position.x = randf_range(-25, 20)
	position.y = randf_range(-0.3, 1.5)
	position.z = -40
	var random_speed := randf_range(2.5, 4.5)
	speed = random_speed
	var random_scale := randf_range(0.8, 2.0)
	scale = Vector3(random_scale, random_scale, random_scale)


func _physics_process(delta: float) -> void:
	if can_move:
		direction = global_position.direction_to(player_position)
		position += direction * speed * delta
		rotate_x(randf_range(2.0, 0.5) * delta)
		rotate_z(randf_range(2.0, 0.5) * delta)


func _on_area_entered(area: Area3D) -> void:
	$AudioStreamPlayer3D.play()
	can_move = false
	area.destroy()
	$meteor.material_overlay.set_shader_parameter("progress", 1.0)
	await get_tree().create_timer(0.4).timeout
	queue_free()


func _on_body_entered(_player: CharacterBody3D) -> void:
	get_tree().quit()


func _on_visible_on_screen_notifier_3d_screen_exited() -> void:
	queue_free()
