extends Node3D


# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	#$MeshInstance3D.mesh.material.albedo_color = Color(1.0, 1.0, 0.0, 0.2)
	pass

# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	$MeshInstance3D.position.x += 5 * delta
