extends Area3D

const SPEED: float = 15.0
const direction: float = -1.0
var can_move := true


# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	scale = Vector3(0.1, 0.1, 0.1)
	var tween = create_tween()
	tween.tween_property(self, "scale", Vector3.ONE, 0.4)	
	$AudioStreamPlayer3D.play()


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _physics_process(delta: float) -> void:
	if can_move:
		position.z += SPEED * direction * delta
		if position.z < -200:
			queue_free()


func setup(player_position: Vector3):
	position = player_position + Vector3(0, 0, -1.8)


func destroy() -> void:
	can_move = false
	$Red.material_overlay.set_shader_parameter("progress", 1.0)
	await get_tree().create_timer(0.4).timeout
	queue_free()
