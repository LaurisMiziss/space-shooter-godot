extends Node3D


var laser_scene: PackedScene = preload("res://scenes/laser.tscn")
var meteor_scene: PackedScene = preload("res://scenes/meteor.tscn")
var obstacle_scene: PackedScene = preload("res://scenes/obstacle.tscn")
var game_size = {
	"left": -15,
	"right": 15,
	"back": -40,
	"front": -2
}


# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	for i in range(50):
		var obstacle = obstacle_scene.instantiate() as Area3D
		$Obstacles.add_child(obstacle)
		obstacle.set_x_z_position(
			randf_range(game_size["left"], game_size["right"]),
			randf_range(game_size["front"], game_size["back"] + 5),
		)


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(_delta: float) -> void:
	pass


func _on_player_shoot_laser(player_position: Vector3) -> void:
	var laser = laser_scene.instantiate() as Area3D
	laser.setup(player_position)
	$Lasers.add_child(laser)


func _on_meteor_timer_timeout() -> void:
	var meteor = meteor_scene.instantiate() as Area3D
	$Meteors.add_child(meteor)
	meteor.player_position = Vector3($Player.global_position.x, $Player.global_position.y, $Player.global_position.z + 21)


func _on_obstacle_timer_timeout() -> void:
	for i in randi_range(3, 6):
		spawn_obstacle()

func spawn_obstacle():
	var obstacle = obstacle_scene.instantiate() as Area3D
	$Obstacles.add_child(obstacle)
	obstacle.set_x_z_position(
		randf_range(game_size["left"], game_size["right"]),
		randf_range(game_size["back"], game_size["back"] + 5),
	)
