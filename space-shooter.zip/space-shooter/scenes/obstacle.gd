extends Area3D

const SPEED: float = 3.0


# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	position.y = -2
	var random_scale = randf_range(1, 3)
	scale = Vector3(random_scale, random_scale, random_scale)
	rotate_y(randf_range(0, TAU))
	var element: Node3D = $Meshes.get_children().pick_random()
	var childs = $Meshes.get_children()
	for child in childs:
		if child != element:
			child.queue_free()
	
# Called every frame. 'delta' is the elapsed time since the previous frame.
func _physics_process(delta: float) -> void:
	position += Vector3(0.0, 0.0, 1.0) * SPEED * delta
	
	
func set_x_z_position(x_pos: float, z_pos: float):
	position.x = x_pos
	position.z = z_pos


func _on_body_entered(_body: Node3D) -> void:
	get_tree().quit()
